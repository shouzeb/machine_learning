# -*- coding: utf-8 -*-

"""

Created on Tue Feb 25 19:57:59 2020

@author: Shouzeb

"""

from sklearn.datasets import load_iris
iriss=load_iris()
print(iris.feature_names)
